package com.luxoft.test.uploadcsvfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadCsvFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
